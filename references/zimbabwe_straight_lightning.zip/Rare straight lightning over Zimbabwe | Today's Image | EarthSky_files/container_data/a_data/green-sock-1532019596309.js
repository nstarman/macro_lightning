var tl = TweenLite;

// intro animations
tl.to(banner, 0.5, { opacity:1, ease:Power0.easeNone });
// ---------------------
// cta
function resetShine() {
	shine.style.left = '-220px';
}
tl.to(cta, 0.45, { bottom: 25, opacity: 1, ease: Back.easeOut, delay: 0.4 });
tl.to(shine, 0.8, { left: 320, ease: Power0.easeNone, delay: 2.8, onComplete: resetShine });
//
tl.to(shine, 0.8, { left: 320, ease: Power0.easeNone, delay: 8.4, onComplete: resetShine });
//
tl.to(shine, 0.8, { left: 320, ease: Power0.easeNone, delay: 13.9 });


// get slider value
function spliceStr(str, index, count, add) {
	return str.slice(0, index) + (add || '') + str.slice(index + count);
}

// main hit clickTAG functions
function hitClick(e) {
	var separator = clickTag.indexOf('?') > -1 ? '&' : '?';
	revjet.elements.runAction({
    "type": "link",
    "sourceWidgetId": sourceWidgetId,
    "url": clickTAG  + separator + 'desired-loan-amount=' + cash + '&estproperty-value=' + cash + '&purchase-price=' + cash,
    "target": "_blank"
});	
}

function hitOver() {
	cta.className = 'hl';
}

function hitOut() {
	cta.className = '';
}

hit.addEventListener('mouseover', hitOver);
hit.addEventListener('mouseout', hitOut);
hit.addEventListener('click', hitClick);

// slider features
var dragging = false;
var drag_x;
var sliderval = 0;
var maxval = 740;
var cash;
var MOUSE = 0;
var TOUCH = 1;

function setCash(value) {
	var pvalue = Math.round(Math.floor(value * 995 + 5) / 5) * 5 + '000';
	var formatted = '';
	var i = pvalue.length;
	var c = 0;
	while (i--) {
		formatted += pvalue[i];
		c++;
		if (i > 0 && c === 3) {
			formatted += ',';
			c = 0;
		}
	}
	var pstr = '$' + formatted.split('').reverse().join('');
	labelcash.innerHTML = pstr;
	cash = pvalue;
}

function setSliderPos(value) {
	sliderval = value;
	pivot.style.left = value + 'px';
	var perc = Math.floor(value / maxval * 100);
	sliderfill.style.width = perc + '%';
	setCash(value / maxval);
}

function updateSliderPos(event_x) {
	var new_x = event_x - sliderhit.getBoundingClientRect().left - 9;
	new_x = Math.min(Math.max(0, new_x), maxval);
	setSliderPos(new_x);
}

function sliderMDown(e, agent) {
	var ex = (agent === TOUCH) ? e.changedTouches[0] : e;
	if (agent === MOUSE) {
		var button = e.which || e.button;
		if (button !== 1)
			return;
	}
	else if (e.preventDefault) {
		e.preventDefault();
	}
	if (sliderAnim) {
		sliderAnim.kill();
		sliderAnim = null;
	}
	dragging = true;
	updateSliderPos(ex.clientX);
}

function sliderMMove(e, agent) {
	var ex = (agent === TOUCH) ? e.changedTouches[0] : e;
	if (dragging) {
		updateSliderPos(ex.clientX);
	}
}

function sliderMUp(e, agent) {
	if (agent === MOUSE) {
		var button = e.which || e.button;
		if (button !== 1) {
			return;
		}
	}
	if (dragging) {
		dragging = false;
	}
}

function sliderMOver(e) {
	pivotbgover.style.opacity = 1;
}

function sliderMOut(e) {
	pivotbgover.style.opacity = 0;
}

sliderhit.addEventListener('mouseover', sliderMOver, false);
sliderhit.addEventListener('mouseout', sliderMOut, false);
sliderhit.addEventListener('mousedown', function(e) { sliderMDown(e, MOUSE); }, false);
sliderhit.addEventListener('touchstart', function(e) { sliderMDown(e, TOUCH); }, false);
window.addEventListener('mousemove', function(e) { sliderMMove(e, MOUSE); }, false);
window.addEventListener('touchmove', function(e) { sliderMMove(e, TOUCH); }, false);
window.addEventListener('mouseup', function(e) { sliderMUp(e, MOUSE); }, false);
window.addEventListener('touchend', function(e) { sliderMUp(e, TOUCH); }, false);

// slider animation
var pos = [0];
var sliderAnim;
setSliderPos(0);
tl.to(cashslider, 0.8, { opacity: 1, ease: Power0.easeNone, delay: 0.1 });
sliderAnim = tl.to(pos, 2.5, { 0: maxval / 4.51, ease: Back.easeOut, onUpdate: function() {
	setSliderPos(pos[0]);
}, delay: 0.8 });