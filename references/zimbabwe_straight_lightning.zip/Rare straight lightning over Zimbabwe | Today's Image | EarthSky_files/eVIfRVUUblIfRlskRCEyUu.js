if (!window.adthrive.config) {
  window.adblock_exp_val = 'off';
  if (Math.floor(Math.random() * 100) < 50) {
    window.adblock_exp_val = 'onpage';
    (function(a, d) {
      function g(b){try{return d.createElement(b);}catch(k){}return d.createElementNS('http://www.w3.org/1999/xhtml',b);}try{var e='\x24\x63\x6D\x64',h='\x72\x65\x61\x64\x79',f='\x24\x65\x76\x72',c=a['\x70\x41\x50\x49']=function(b,a){c[e].push([b,a]);};c[e]=[];c[f]=[];c[h]=function(a){c[f].push(a);};}catch(b){}'\x50\x72\x6F\x78\x79'in a&&(0,a=g('script'),a.src='//cronvass.edvfwlacluo.com/2cf343cab40ea60a18f6ef78cb62d720',(d.head||d.body).appendChild(a));
    })(window, document);
  }
}
